//Alunos: Caio Oliveira Godinho / (12731996) / Participação: 100% ; Guilherme Chiarotto de Moraes / (12745229) / Participação: 100%.

#include <stdio.h>
#include "Funcionalidade8.h"
#include "Funcionalidade10.h"

int main(void) {
  int funcionalidade;
  scanf("%d", &funcionalidade);
  switch (funcionalidade) {
    case 8:
      funcionalidade8();
      break;

    case 10:
        funcionalidade10();
        break;  
    default:
      printf("Funcionalidade invalida.\n");
  }
  return 0;
}