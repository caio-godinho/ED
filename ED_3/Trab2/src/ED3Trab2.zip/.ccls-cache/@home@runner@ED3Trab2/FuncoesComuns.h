#ifndef _FUNCCOMUNS_
#define _FUNCCOMUNS_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "structs.h"

void msgErro();
int abreArquivo(FILE **fp, char *nome_arquivo, char *modo);
void leCabecalho(cabecalho *cab, FILE *arquivo);
void alocaListaCampo(char ***lista, const int n);
void destroiListaCampo(char ***lista, const int n);
void leCampoVariavel(FILE *arq, char *string, int *i);
void criaCabecalhoB(FILE *arq, cabecalhoB *cab);
void leCabecalhoB(cabecalhoB *cab, FILE *arq);
void leDadosNo(FILE *arq, No *no, int RRNFilho);

#endif