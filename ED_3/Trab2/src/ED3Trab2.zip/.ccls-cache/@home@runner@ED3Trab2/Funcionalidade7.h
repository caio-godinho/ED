#ifndef _FUNCIONALIDADE7_
#define _FUNCIONALIDADE7_

#include "structs.h"

void funcionalidade7();

#endif