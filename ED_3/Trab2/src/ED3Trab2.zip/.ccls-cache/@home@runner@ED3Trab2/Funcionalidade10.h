#ifndef _FUNCIONALIDADE10_
#define _FUNCIONALIDADE10_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include"structs.h"

void print_registroIdConectado(const registro reg);
void print_registroIdPoPs(const registro reg);
void funcionalidade10();

#endif