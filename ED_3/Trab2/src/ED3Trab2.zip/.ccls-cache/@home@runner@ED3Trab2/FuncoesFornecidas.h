#ifndef FORNECIDAS
#define FORNECIDAS

void readline(char* string);
void binarioNaTela(char *nomeArquivoBinario);
void scan_quote_string(char *str);

#endif