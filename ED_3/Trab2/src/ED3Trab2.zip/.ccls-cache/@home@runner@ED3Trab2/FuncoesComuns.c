#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "FuncoesFornecidas.h"
#include "structs.h"

//Mensagem caso aconteca algum erro
void msgErro() { 
  printf("Falha no processamento do arquivo.\n");
}

//Abre arquivo com o modo necessário
int abreArquivo(FILE **fp, char *nome_arquivo, char *modo) {
  (*fp) = fopen(nome_arquivo, modo);
  if((*fp) == NULL) {
    msgErro();
    return -1;
  }
  return 0;
}

void leCabecalho(cabecalho *cab, FILE *arquivo){
    fseek(arquivo, 0, SEEK_SET);
    fread(&cab->status, sizeof(char), 1, arquivo);
    if(cab->status == '0'){
        msgErro();
        exit(0);
    }
    fread(&cab->topo, sizeof(int), 1, arquivo);
    fread(&cab->proxRRN, sizeof(int), 1, arquivo);
    fread(&cab->nroRegRem, sizeof(int), 1, arquivo);
    fread(&cab->nroPagDisco, sizeof(int), 1, arquivo);
    fread(&cab->qttCompacta, sizeof(int), 1, arquivo);
}

void alocaListaCampo(char ***lista, const int n) {
  *lista = (char**) malloc(sizeof(char *) * n);
  for(int i = 0; i < n; i++)
    (*lista)[i] = (char*) malloc(sizeof(char) * 30);
}

void destroiListaCampo(char ***lista, const int n) {
  for(int i = 0; i < n; i++) {
    free((*lista)[i]);
    (*lista)[i] = NULL;
  }
  free(*lista);
  *lista = NULL;
}

void leCampoVariavel(FILE *arq, char *string, int *i) {
  *i = 0;
  do{
      fread(&(string[*i]), 1, 1, arq);
      (*i)++;
  }while(string[*i - 1] != '|');
  string[*i - 1] = '\0';
}

//Cria o cabecalho do arquivo de indices
void criaCabecalhoB(FILE *arq, cabecalhoB *cab){
  //Inicializa variaveis do cabecalho
  cab->status = '0';
  cab->noRaiz = -1;
  cab->nroChavesTotal = 0;
  cab->alturaArvore = 0;
  cab->RRNproxNo = 0;

  //Insere no cabecalho
  fwrite(&cab->status, sizeof(char), 1, arq);
  fwrite(&(cab->noRaiz), sizeof(int), 1, arq);
  fwrite(&(cab->nroChavesTotal), sizeof(int), 1, arq);
  fwrite(&(cab->alturaArvore), sizeof(int), 1, arq);
  fwrite(&(cab->RRNproxNo), sizeof(int), 1, arq);
  for(int i = 0; i < TamPagDisco - TamCabecalho; i++)
    fwrite(LIXO, sizeof(char), 1, arq);
}

//Le o cabecalho e vê se o arquivo é consistente
void leCabecalhoB(cabecalhoB *cab, FILE *arq){
    fseek(arq, 0, SEEK_SET);
    fread(&cab->status, sizeof(char), 1, arq);
    if(cab->status == '0'){
        msgErro();
        exit(0); //arquivo inconsistente para execução
    }
    fread(&cab->noRaiz, sizeof(int), 1, arq);
    fread(&cab->nroChavesTotal, sizeof(int), 1, arq);
    fread(&cab->alturaArvore, sizeof(int), 1, arq);
    fread(&cab->RRNproxNo, sizeof(int), 1, arq);
}
