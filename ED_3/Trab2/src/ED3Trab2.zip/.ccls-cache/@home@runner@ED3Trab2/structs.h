#ifndef _STRUCTS_
#define _STRUCTS_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Ordem da árvore-B
#define ORDEM 5

//Caractere utilizado para representar o lixo
#define LIXO "$"

//Tamanho das páginas de disco, do registro de cabeçalho e dos nós
#define TamPagDisco 65

//Quantidade de bytes preechidos pelos campos do cabecalho
#define TamCabecalho 17


//Struct que representa cada elemento dentro de um nó
typedef struct _elemento {
  int Pr;          //RRN dos elemento no arquivo de dados
  int C;          //chave do elemento
} elemento;

//Struct que representa um nó na árvore-B
typedef struct _No {
  char folha;           //Se nó é folha(1) ou não(0) 
  int nroChavesNo;      //Número de chaves de indexação 
  int alturaNo;         //Nível em que nó se encontra na árvore
  int RRNdoNo;          //RRN do nó no arquivo de índices
  elemento elementos[ORDEM - 1];  //lista de elementos
  int P[ORDEM];              //Ponteiro que guarda RRNs dos nós filhos
} No;

//Struct que representa o registro de cabecalho
typedef struct _cabecalho{
  char status;         //Consistência do arquivo de índice
  int noRaiz;          //RRN do nó raiz
  int nroChavesTotal;  //Número de chaves de busca
  int alturaArvore;    //Indica a altura da árvore
  int RRNproxNo;       //Indica RRN do próximo nó a ser inserido
} cabecalhoB;

typedef struct { 
  //registro de cabecalho
  char status;
  int topo;
  int proxRRN;
  int nroRegRem;
  int nroPagDisco;
  int qttCompacta;

} cabecalho;

typedef struct {
  //Campos de controle para gerenciamento de registros removidos
  char removido[2];
  int encadeamento;

  //Campos de tamanho fixo
  int idConecta;
  char siglaPais[3];
  int idPoPsConectado;
  char unidadeMedida[2];
  int velocidade;

  //Campos de tamanho variavel
  char nomePoPs[100];
  char nomePais[100];

} registro;

#endif