#ifndef _FUNCIONALIDADE2_
#define _FUNCIONALIDADE2_
#include "structs.h"

void le_arquivo(cabecalho cab, registro *reg, FILE *arquivo);
void funcionalidade2();

#endif