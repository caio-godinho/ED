#ifndef _FUNCIONALIDADE5_
#define _FUNCIONALIDADE5_
#include "structs.h"

void insere_registro(registro *reg, cabecalho *cab, FILE *arq);
void copia_inteiro(int *campo, char *valor);
void copia_string(char *campo, char *valor);
void funcionalidade5();

#endif